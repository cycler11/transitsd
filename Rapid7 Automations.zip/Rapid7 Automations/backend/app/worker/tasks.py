from __future__ import annotations

from datetime import UTC, datetime

from app.worker.celery_app import celery_app
from sqlalchemy import func, select

from app.db.session import SessionLocal
from app.models import Asset, Rapid7Connection, ScanJob, ScanRun, ScanRunStatus, Severity, Vulnerability
from app.rapid7.client import get_rapid7_client
from app.utils.normalization import normalize_asset, normalize_vulnerability


@celery_app.task(name="app.worker.tasks.enqueue_scan_run")
def enqueue_scan_run(scan_run_id: str) -> None:
    with SessionLocal() as db:
        run = db.get(ScanRun, scan_run_id)
        if not run:
            return
        run.status = ScanRunStatus.running
        run.started_at = datetime.now(UTC)
        db.commit()

        job = db.get(ScanJob, run.scan_job_id)
        if not job:
            run.status = ScanRunStatus.failed
            run.error = "Missing scan job"
            run.finished_at = datetime.now(UTC)
            db.commit()
            return

        conn = db.get(Rapid7Connection, job.connection_id)
        if not conn:
            run.status = ScanRunStatus.failed
            run.error = "Missing connection"
            run.finished_at = datetime.now(UTC)
            db.commit()
            return

        client = get_rapid7_client(conn)
        try:
            scan_id = client.start_scan(site_id=job.rapid7_site_id)
            run.rapid7_scan_id = scan_id
            db.commit()

            # In scaffold, immediately "complete" in mock mode
            status = client.get_scan_status(scan_id=scan_id)
            _ = status

            # Sync some entities from fixtures
            for a in client.fetch_assets():
                na = normalize_asset(a)
                db.merge(na)
            for v in client.fetch_vulnerabilities():
                nv = normalize_vulnerability(v)
                db.merge(nv)
            db.commit()

            run.status = ScanRunStatus.completed
            run.finished_at = datetime.now(UTC)
            run.stats = {"assets_synced": int(db.scalar(select(func.count()).select_from(Asset)) or 0)}
            db.commit()
        except Exception as e:
            run.status = ScanRunStatus.failed
            run.error = str(e)
            run.finished_at = datetime.now(UTC)
            db.commit()


@celery_app.task(name="app.worker.tasks.periodic_sync")
def periodic_sync() -> None:
    # For scaffold: no-op unless scan jobs exist; future: inspect cron schedules and queue runs.
    return

