from __future__ import annotations

from celery import Celery

from app.core.config import settings

celery_app = Celery(
    "rapid7_automation",
    broker=settings.redis_url,
    backend=settings.redis_url,
    include=["app.worker.tasks"],
)

celery_app.conf.update(
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    broker_connection_retry_on_startup=True,
    timezone="UTC",
    beat_schedule={
        # placeholder periodic sync; in real version, schedule per scan_job.schedule_cron
        "mock-periodic-sync": {
            "task": "app.worker.tasks.periodic_sync",
            "schedule": 60.0,
        }
    },
)

