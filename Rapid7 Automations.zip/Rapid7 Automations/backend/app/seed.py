from __future__ import annotations

import sys

from sqlalchemy import select

from app.core.config import settings
from app.core.security import hash_password
from app.db.session import SessionLocal
from app.models import Role, RoleName, User, UserRole


def ensure_roles(db) -> dict[RoleName, Role]:
    existing = {r.name: r for r in db.execute(select(Role)).scalars().all()}
    out: dict[RoleName, Role] = {}
    for name in (RoleName.admin, RoleName.security_analyst, RoleName.viewer):
        role = existing.get(name)
        if not role:
            role = Role(name=name)
            db.add(role)
            db.flush()
        out[name] = role
    return out


def main() -> int:
    with SessionLocal() as db:
        roles = ensure_roles(db)
        user = db.execute(select(User).where(User.email == settings.seed_admin_email)).scalar_one_or_none()
        if not user:
            user = User(email=settings.seed_admin_email, password_hash=hash_password(settings.seed_admin_password))
            db.add(user)
            db.flush()
        # ensure admin role
        exists = db.execute(
            select(UserRole).where(UserRole.user_id == user.id, UserRole.role_id == roles[RoleName.admin].id)
        ).scalar_one_or_none()
        if not exists:
            db.add(UserRole(user_id=user.id, role_id=roles[RoleName.admin].id))
        db.commit()

    print(f"Seeded admin user: {settings.seed_admin_email}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

