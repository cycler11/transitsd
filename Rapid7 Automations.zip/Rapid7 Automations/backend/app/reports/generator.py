from __future__ import annotations

import os
from datetime import UTC, datetime
from pathlib import Path

import xlsxwriter
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Asset, Report, Severity, Vulnerability
from app.utils.priority import remediation_priority_score


def _severity_format(workbook: xlsxwriter.Workbook):
    return {
        Severity.critical: workbook.add_format({"bg_color": "#B71C1C", "font_color": "#FFFFFF"}),
        Severity.high: workbook.add_format({"bg_color": "#D32F2F", "font_color": "#FFFFFF"}),
        Severity.medium: workbook.add_format({"bg_color": "#F57C00", "font_color": "#FFFFFF"}),
        Severity.low: workbook.add_format({"bg_color": "#FBC02D"}),
        Severity.info: workbook.add_format({"bg_color": "#1976D2", "font_color": "#FFFFFF"}),
    }


def generate_xlsx_report_from_db(*, db: Session, report_id: str) -> str:
    root = Path(os.environ.get("REPORT_DIR", "/app/data/reports"))
    root.mkdir(parents=True, exist_ok=True)
    file_path = root / f"report-{report_id}.xlsx"

    workbook = xlsxwriter.Workbook(file_path.as_posix(), {"constant_memory": True})
    header_fmt = workbook.add_format({"bold": True, "bg_color": "#ECEFF1"})
    sev_fmt = _severity_format(workbook)

    # Assets sheet
    ws_assets = workbook.add_worksheet("Assets")
    assets = db.execute(select(Asset).order_by(Asset.created_at.desc())).scalars().all()
    asset_headers = ["Asset ID", "Hostname", "IP", "Rapid7 Asset ID", "Created At"]
    ws_assets.write_row(0, 0, asset_headers, header_fmt)
    for i, a in enumerate(assets, start=1):
        ws_assets.write(i, 0, str(a.id))
        ws_assets.write(i, 1, a.hostname or "")
        ws_assets.write(i, 2, a.ip or "")
        ws_assets.write(i, 3, a.rapid7_asset_id or "")
        ws_assets.write(i, 4, a.created_at.isoformat())
    ws_assets.freeze_panes(1, 0)
    ws_assets.autofilter(0, 0, max(1, len(assets)), len(asset_headers) - 1)

    # Vulnerabilities sheet
    ws_v = workbook.add_worksheet("Vulnerabilities")
    vulns = db.execute(select(Vulnerability).order_by(Vulnerability.created_at.desc())).scalars().all()
    v_headers = ["Vuln ID", "Title", "Severity", "CVSS", "Priority", "Rapid7 Vuln ID"]
    ws_v.write_row(0, 0, v_headers, header_fmt)
    for i, v in enumerate(vulns, start=1):
        ws_v.write(i, 0, str(v.id))
        ws_v.write(i, 1, v.title)
        ws_v.write(i, 2, v.severity.value, sev_fmt.get(v.severity))
        ws_v.write(i, 3, v.cvss_score or "")
        pri = remediation_priority_score(severity=v.severity, cvss_score=v.cvss_score)
        ws_v.write(i, 4, pri)
        ws_v.write(i, 5, v.rapid7_vuln_id or "")
    ws_v.freeze_panes(1, 0)
    ws_v.autofilter(0, 0, max(1, len(vulns)), len(v_headers) - 1)

    workbook.close()

    rpt = db.get(Report, report_id)
    if rpt:
        rpt.generated_at = datetime.now(UTC)
        db.commit()

    return file_path.as_posix()

