from __future__ import annotations

import base64

from cryptography.fernet import Fernet, InvalidToken

from app.core.config import settings


def _fernet() -> Fernet:
    key = settings.encryption_key.encode("utf-8")
    return Fernet(key)


def encrypt_str(plaintext: str) -> str:
    token = _fernet().encrypt(plaintext.encode("utf-8"))
    return base64.urlsafe_b64encode(token).decode("utf-8")


def decrypt_str(token_b64: str) -> str:
    try:
        token = base64.urlsafe_b64decode(token_b64.encode("utf-8"))
        out = _fernet().decrypt(token)
        return out.decode("utf-8")
    except (InvalidToken, ValueError) as e:
        raise ValueError("Invalid encrypted value") from e


def mask_secret(value: str | None) -> str | None:
    if value is None or value == "":
        return value
    if len(value) <= 4:
        return "****"
    return f"{value[:2]}****{value[-2:]}"

