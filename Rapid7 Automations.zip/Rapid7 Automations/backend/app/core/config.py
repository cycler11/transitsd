from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=None, extra="ignore")

    env: str = "dev"
    log_level: str = "INFO"

    # Security
    encryption_key: str
    jwt_secret: str
    jwt_algorithm: str = "HS256"
    jwt_access_token_expires_minutes: int = 60

    # DB / cache
    database_url: str
    redis_url: str = "redis://redis:6379/0"

    # Rapid7 connectivity
    rapid7_base_url: str | None = None
    rapid7_api_version: str = "v1"
    rapid7_verify_tls: bool = True
    rapid7_timeout_seconds: int = 30

    # Behavior
    mock_mode: bool = False

    # Seed
    seed_admin_email: str = "admin@example.com"
    seed_admin_password: str = "ChangeMe123!"


settings = Settings()  # type: ignore[call-arg]
