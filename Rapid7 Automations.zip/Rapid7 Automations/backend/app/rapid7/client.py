from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

import httpx
from tenacity import retry, stop_after_attempt, wait_exponential

from app.core.config import settings
from app.models.rapid7 import Rapid7Connection


class Rapid7Client:
    def __init__(self, *, base_url: str, api_version: str, api_token: str, verify_tls: bool, timeout_seconds: int):
        self.base_url = base_url.rstrip("/")
        self.api_version = api_version
        self.api_token = api_token
        self.verify_tls = verify_tls
        self.timeout_seconds = timeout_seconds

        self._client = httpx.Client(
            timeout=httpx.Timeout(timeout_seconds),
            verify=verify_tls,
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json",
                "X-Api-Version": api_version,
                "Authorization": f"Bearer {api_token}",
            },
        )

    def close(self) -> None:
        self._client.close()

    @retry(stop=stop_after_attempt(5), wait=wait_exponential(multiplier=0.5, min=0.5, max=8))
    def _request(self, method: str, path: str, *, params: dict[str, Any] | None = None, json_body: Any | None = None) -> Any:
        url = f"{self.base_url}{path}"
        resp = self._client.request(method, url, params=params, json=json_body)
        if resp.status_code in (429, 500, 502, 503, 504):
            raise httpx.HTTPStatusError("Retryable error", request=resp.request, response=resp)
        resp.raise_for_status()
        if resp.content:
            return resp.json()
        return None

    def test_connection(self) -> bool:
        # Do not assume a specific endpoint; just validate base_url and auth with a configurable ping path later.
        # For scaffold, treat success if we can GET root.
        try:
            self._request("GET", "/")
            return True
        except Exception:
            return False

    def start_scan(self, *, site_id: str | None) -> str:
        # Placeholder: real implementation depends on Nexpose/InsightVM version-specific endpoints
        payload = {"site_id": site_id}
        out = self._request("POST", "/api/scans", json_body=payload)
        return str(out.get("scan_id", "mock-scan"))

    def get_scan_status(self, *, scan_id: str) -> dict[str, Any]:
        out = self._request("GET", f"/api/scans/{scan_id}")
        return dict(out)

    def fetch_assets(self) -> list[dict[str, Any]]:
        # Placeholder pagination; real endpoints must be configured.
        out = self._request("GET", "/api/assets", params={"page": 0, "size": 500})
        return list(out.get("items", []))

    def fetch_vulnerabilities(self) -> list[dict[str, Any]]:
        out = self._request("GET", "/api/vulnerabilities", params={"page": 0, "size": 500})
        return list(out.get("items", []))


class MockRapid7Client:
    def __init__(self) -> None:
        self._root = Path(__file__).resolve().parents[2] / "mock_data"

    def _load(self, name: str) -> Any:
        p = self._root / name
        return json.loads(p.read_text(encoding="utf-8"))

    def test_connection(self) -> bool:
        return True

    def start_scan(self, *, site_id: str | None) -> str:
        _ = site_id
        return f"mock-scan-{int(time.time())}"

    def get_scan_status(self, *, scan_id: str) -> dict[str, Any]:
        _ = scan_id
        return {"status": "completed"}

    def fetch_assets(self) -> list[dict[str, Any]]:
        return list(self._load("assets.json"))

    def fetch_vulnerabilities(self) -> list[dict[str, Any]]:
        return list(self._load("vulnerabilities.json"))


def get_rapid7_client(conn: Rapid7Connection):
    if settings.mock_mode:
        return MockRapid7Client()
    return Rapid7Client(
        base_url=conn.base_url,
        api_version=conn.api_version,
        api_token=conn.api_token,
        verify_tls=conn.verify_tls,
        timeout_seconds=settings.rapid7_timeout_seconds,
    )

