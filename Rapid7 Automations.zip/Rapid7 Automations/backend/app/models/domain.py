from __future__ import annotations

import enum
import uuid
from datetime import UTC, datetime

from sqlalchemy import DateTime, Enum, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base
from app.models.common import TimestampMixin, UUIDMixin, utcnow


class ScanJobStatus(str, enum.Enum):
    idle = "idle"
    queued = "queued"
    running = "running"
    failed = "failed"


class ScanRunStatus(str, enum.Enum):
    queued = "queued"
    running = "running"
    completed = "completed"
    failed = "failed"


class Severity(str, enum.Enum):
    critical = "critical"
    high = "high"
    medium = "medium"
    low = "low"
    info = "info"


class Asset(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "assets"

    hostname: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    ip: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    rapid7_asset_id: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    metadata: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)

    open_ports: Mapped[list["OpenPort"]] = relationship(back_populates="asset", cascade="all, delete-orphan")
    software: Mapped[list["Software"]] = relationship(back_populates="asset", cascade="all, delete-orphan")


class ScanJob(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "scan_jobs"

    name: Mapped[str] = mapped_column(String(200), unique=True, index=True, nullable=False)
    connection_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("rapid7_connections.id"), nullable=False, index=True)
    rapid7_site_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    schedule_cron: Mapped[str | None] = mapped_column(String(64), nullable=True)
    status: Mapped[ScanJobStatus] = mapped_column(Enum(ScanJobStatus, name="scan_job_status"), default=ScanJobStatus.idle, nullable=False)
    config: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)


class ScanRun(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "scan_runs"

    scan_job_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("scan_jobs.id", ondelete="CASCADE"), index=True, nullable=False)
    status: Mapped[ScanRunStatus] = mapped_column(Enum(ScanRunStatus, name="scan_run_status"), default=ScanRunStatus.queued, nullable=False)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    rapid7_scan_id: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    stats: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)


class Vulnerability(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "vulnerabilities"

    rapid7_vuln_id: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    severity: Mapped[Severity] = mapped_column(Enum(Severity, name="severity"), nullable=False, default=Severity.medium)
    cvss_score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    cves: Mapped[list[str]] = mapped_column(JSONB, nullable=False, default=list)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    remediation: Mapped[str | None] = mapped_column(Text, nullable=True)
    references: Mapped[list[str]] = mapped_column(JSONB, nullable=False, default=list)


class AssetVulnerability(TimestampMixin, Base):
    __tablename__ = "asset_vulnerabilities"
    __table_args__ = (UniqueConstraint("asset_id", "vulnerability_id", name="uq_asset_vuln"),)

    asset_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("assets.id", ondelete="CASCADE"), primary_key=True)
    vulnerability_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("vulnerabilities.id", ondelete="CASCADE"), primary_key=True)
    status: Mapped[str] = mapped_column(String(50), nullable=False, default="open")
    proof: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)


class Software(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "software"

    asset_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("assets.id", ondelete="CASCADE"), index=True, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    version: Mapped[str | None] = mapped_column(String(128), nullable=True)
    vendor: Mapped[str | None] = mapped_column(String(255), nullable=True)

    asset: Mapped[Asset] = relationship(back_populates="software")


class OpenPort(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "open_ports"

    asset_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("assets.id", ondelete="CASCADE"), index=True, nullable=False)
    port: Mapped[int] = mapped_column(Integer, nullable=False)
    protocol: Mapped[str] = mapped_column(String(16), nullable=False, default="tcp")
    service: Mapped[str | None] = mapped_column(String(255), nullable=True)

    asset: Mapped[Asset] = relationship(back_populates="open_ports")


class Report(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "reports"

    name: Mapped[str] = mapped_column(String(255), nullable=False)
    kind: Mapped[str] = mapped_column(String(50), nullable=False, default="xlsx")
    params: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    file_path: Mapped[str | None] = mapped_column(Text, nullable=True)
    generated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class AuditLog(UUIDMixin, Base):
    __tablename__ = "audit_logs"

    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False, index=True)
    actor_user_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True, index=True)
    action: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    entity: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    entity_id: Mapped[str | None] = mapped_column(String(100), nullable=True, index=True)
    details: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
