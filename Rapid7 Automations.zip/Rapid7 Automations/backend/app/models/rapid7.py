from __future__ import annotations

from sqlalchemy import Boolean, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.crypto import decrypt_str, encrypt_str
from app.db.session import Base
from app.models.common import TimestampMixin, UUIDMixin


class Rapid7Connection(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "rapid7_connections"

    name: Mapped[str] = mapped_column(String(200), unique=True, index=True, nullable=False)
    base_url: Mapped[str] = mapped_column(String(500), nullable=False)
    api_version: Mapped[str] = mapped_column(String(20), nullable=False, default="v1")
    verify_tls: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    # encrypted fields (base64-encoded Fernet token)
    _api_token_enc: Mapped[str] = mapped_column("api_token_enc", Text, nullable=False)

    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    @property
    def api_token(self) -> str:
        return decrypt_str(self._api_token_enc)

    @api_token.setter
    def api_token(self, value: str) -> None:
        self._api_token_enc = encrypt_str(value)

    def masked(self) -> dict[str, object]:
        return {
            "id": str(self.id),
            "name": self.name,
            "base_url": self.base_url,
            "api_version": self.api_version,
            "verify_tls": self.verify_tls,
            "api_token": "****",
            "is_active": self.is_active,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }
