from __future__ import annotations

from app.models import Severity


def remediation_priority_score(*, severity: Severity, cvss_score: int | None) -> int:
    """
    Deterministic priority score (higher = more urgent).
    Designed to be stable across runs and easy to test.
    """
    sev_weight = {
        Severity.critical: 100,
        Severity.high: 70,
        Severity.medium: 40,
        Severity.low: 10,
        Severity.info: 0,
    }[severity]
    cvss = max(0, min(10, cvss_score or 0))
    return int(sev_weight + cvss * 3)

