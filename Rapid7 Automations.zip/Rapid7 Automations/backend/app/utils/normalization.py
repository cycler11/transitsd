from __future__ import annotations

from app.models import Asset, Severity, Vulnerability


def normalize_asset(raw: dict) -> Asset:
    asset = Asset(
        rapid7_asset_id=str(raw.get("id")) if raw.get("id") is not None else None,
        hostname=raw.get("hostname"),
        ip=raw.get("ip"),
        metadata=dict(raw),
    )
    return asset


def _severity_from_raw(raw: str | None) -> Severity:
    if not raw:
        return Severity.medium
    raw_l = raw.lower()
    mapping = {
        "critical": Severity.critical,
        "high": Severity.high,
        "medium": Severity.medium,
        "low": Severity.low,
        "info": Severity.info,
        "informational": Severity.info,
    }
    return mapping.get(raw_l, Severity.medium)


def normalize_vulnerability(raw: dict) -> Vulnerability:
    return Vulnerability(
        rapid7_vuln_id=str(raw.get("id")) if raw.get("id") is not None else None,
        title=str(raw.get("title") or "Untitled"),
        severity=_severity_from_raw(raw.get("severity")),
        cvss_score=int(raw.get("cvss")) if raw.get("cvss") is not None else None,
        cves=list(raw.get("cves") or []),
        description=raw.get("description"),
        remediation=raw.get("remediation"),
        references=list(raw.get("references") or []),
    )

