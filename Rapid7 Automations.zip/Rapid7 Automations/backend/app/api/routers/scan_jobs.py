from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import require_roles
from app.db.session import get_db
from app.models import RoleName, ScanJob, ScanRun
from app.worker.tasks import enqueue_scan_run

router = APIRouter()


class ScanJobCreate(BaseModel):
    name: str
    connection_id: uuid.UUID
    rapid7_site_id: str | None = None
    schedule_cron: str | None = None
    config: dict = {}


@router.get("", dependencies=[Depends(require_roles(RoleName.admin, RoleName.security_analyst, RoleName.viewer))])
def list_scan_jobs(db: Session = Depends(get_db)):
    rows = db.execute(select(ScanJob).order_by(ScanJob.created_at.desc())).scalars().all()
    return [
        {
            "id": str(j.id),
            "name": j.name,
            "connection_id": str(j.connection_id),
            "rapid7_site_id": j.rapid7_site_id,
            "schedule_cron": j.schedule_cron,
            "status": j.status,
            "created_at": j.created_at,
        }
        for j in rows
    ]


@router.post("", status_code=status.HTTP_201_CREATED, dependencies=[Depends(require_roles(RoleName.admin, RoleName.security_analyst))])
def create_scan_job(payload: ScanJobCreate, db: Session = Depends(get_db)):
    job = ScanJob(
        name=payload.name,
        connection_id=payload.connection_id,
        rapid7_site_id=payload.rapid7_site_id,
        schedule_cron=payload.schedule_cron,
        config=payload.config,
    )
    db.add(job)
    db.commit()
    db.refresh(job)
    return {"id": str(job.id)}


@router.post("/{scan_job_id}/run", dependencies=[Depends(require_roles(RoleName.admin, RoleName.security_analyst))])
def run_scan_job(scan_job_id: str, db: Session = Depends(get_db)):
    job = db.get(ScanJob, scan_job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Not found")
    run = ScanRun(scan_job_id=job.id)
    db.add(run)
    db.commit()
    db.refresh(run)
    enqueue_scan_run.delay(str(run.id))
    return {"scan_run_id": str(run.id)}
