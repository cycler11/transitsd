from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.api.deps import require_roles
from app.db.session import get_db
from app.models import RoleName, Report
from app.reports.generator import generate_xlsx_report_from_db

router = APIRouter()


class ReportGenerateRequest(BaseModel):
    name: str = "InsightVM Report"
    kind: str = "xlsx"


@router.post("/generate", dependencies=[Depends(require_roles(RoleName.admin, RoleName.security_analyst))])
def generate_report(payload: ReportGenerateRequest, db: Session = Depends(get_db)):
    rpt = Report(name=payload.name, kind=payload.kind, params={})
    db.add(rpt)
    db.commit()
    db.refresh(rpt)

    if rpt.kind != "xlsx":
        raise HTTPException(status_code=400, detail="Only xlsx supported in scaffold")
    file_path = generate_xlsx_report_from_db(db=db, report_id=str(rpt.id))
    rpt.file_path = file_path
    db.commit()
    return {"report_id": str(rpt.id)}


@router.get("/{report_id}/download", dependencies=[Depends(require_roles(RoleName.admin, RoleName.security_analyst, RoleName.viewer))])
def download_report(report_id: str, db: Session = Depends(get_db)):
    rpt = db.get(Report, report_id)
    if not rpt or not rpt.file_path:
        raise HTTPException(status_code=404, detail="Not found")
    return FileResponse(rpt.file_path, filename=f"{rpt.name}.xlsx")
