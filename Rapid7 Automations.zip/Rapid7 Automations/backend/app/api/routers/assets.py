from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import require_roles
from app.db.session import get_db
from app.models import Asset, RoleName

router = APIRouter()


@router.get("", dependencies=[Depends(require_roles(RoleName.admin, RoleName.security_analyst, RoleName.viewer))])
def list_assets(db: Session = Depends(get_db), limit: int = 100, offset: int = 0):
    rows = (
        db.execute(select(Asset).order_by(Asset.created_at.desc()).limit(limit).offset(offset))
        .scalars()
        .all()
    )
    return {
        "items": [
            {
                "id": str(a.id),
                "hostname": a.hostname,
                "ip": a.ip,
                "rapid7_asset_id": a.rapid7_asset_id,
                "created_at": a.created_at,
            }
            for a in rows
        ],
        "limit": limit,
        "offset": offset,
    }
