from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import require_roles
from app.models import Rapid7Connection, RoleName
from app.db.session import get_db
from app.rapid7.client import get_rapid7_client

router = APIRouter()


class ConnectionCreate(BaseModel):
    name: str
    base_url: str
    api_version: str = "v1"
    verify_tls: bool = True
    api_token: str
    is_active: bool = True


class ConnectionUpdate(BaseModel):
    name: str | None = None
    base_url: str | None = None
    api_version: str | None = None
    verify_tls: bool | None = None
    api_token: str | None = None
    is_active: bool | None = None


@router.get("", dependencies=[Depends(require_roles(RoleName.admin, RoleName.security_analyst, RoleName.viewer))])
def list_connections(db: Session = Depends(get_db)):
    rows = db.execute(select(Rapid7Connection).order_by(Rapid7Connection.created_at.desc())).scalars().all()
    return [r.masked() for r in rows]


@router.post("", status_code=status.HTTP_201_CREATED, dependencies=[Depends(require_roles(RoleName.admin, RoleName.security_analyst))])
def create_connection(payload: ConnectionCreate, db: Session = Depends(get_db)):
    conn = Rapid7Connection(
        name=payload.name,
        base_url=payload.base_url,
        api_version=payload.api_version,
        verify_tls=payload.verify_tls,
        is_active=payload.is_active,
    )
    conn.api_token = payload.api_token
    db.add(conn)
    db.commit()
    db.refresh(conn)
    return conn.masked()


@router.patch("/{connection_id}", dependencies=[Depends(require_roles(RoleName.admin, RoleName.security_analyst))])
def update_connection(connection_id: str, payload: ConnectionUpdate, db: Session = Depends(get_db)):
    conn = db.get(Rapid7Connection, connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Not found")
    for field, value in payload.model_dump(exclude_unset=True).items():
        if field == "api_token":
            conn.api_token = value  # type: ignore[arg-type]
        else:
            setattr(conn, field, value)
    db.commit()
    db.refresh(conn)
    return conn.masked()


@router.delete("/{connection_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(require_roles(RoleName.admin))])
def delete_connection(connection_id: str, db: Session = Depends(get_db)):
    conn = db.get(Rapid7Connection, connection_id)
    if not conn:
        return
    db.delete(conn)
    db.commit()


@router.post("/{connection_id}/test", dependencies=[Depends(require_roles(RoleName.admin, RoleName.security_analyst))])
def test_connection(connection_id: str, db: Session = Depends(get_db)):
    conn = db.get(Rapid7Connection, connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Not found")
    client = get_rapid7_client(conn)
    ok = client.test_connection()
    return {"ok": ok}
