from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import require_roles
from app.db.session import get_db
from app.models import RoleName, ScanRun

router = APIRouter()


@router.get("", dependencies=[Depends(require_roles(RoleName.admin, RoleName.security_analyst, RoleName.viewer))])
def list_scan_runs(db: Session = Depends(get_db), limit: int = 100, offset: int = 0):
    rows = (
        db.execute(select(ScanRun).order_by(ScanRun.created_at.desc()).limit(limit).offset(offset))
        .scalars()
        .all()
    )
    return {
        "items": [
            {
                "id": str(r.id),
                "scan_job_id": str(r.scan_job_id),
                "status": r.status,
                "started_at": r.started_at,
                "finished_at": r.finished_at,
                "error": r.error,
                "created_at": r.created_at,
            }
            for r in rows
        ],
        "limit": limit,
        "offset": offset,
    }


@router.get("/{scan_run_id}", dependencies=[Depends(require_roles(RoleName.admin, RoleName.security_analyst, RoleName.viewer))])
def get_scan_run(scan_run_id: str, db: Session = Depends(get_db)):
    r = db.get(ScanRun, scan_run_id)
    if not r:
        raise HTTPException(status_code=404, detail="Not found")
    return {
        "id": str(r.id),
        "scan_job_id": str(r.scan_job_id),
        "status": r.status,
        "started_at": r.started_at,
        "finished_at": r.finished_at,
        "rapid7_scan_id": r.rapid7_scan_id,
        "error": r.error,
        "stats": r.stats,
        "created_at": r.created_at,
    }
