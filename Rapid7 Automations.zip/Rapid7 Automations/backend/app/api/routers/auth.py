from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import create_access_token, verify_password
from app.db.session import get_db
from app.models import RoleName, User, UserRole

router = APIRouter(prefix="/auth")


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: RoleName


@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)) -> TokenResponse:
    user = db.execute(select(User).where(User.email == payload.email)).scalar_one_or_none()
    if not user or not user.is_active or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")

    # pick highest role by precedence
    roles = (
        db.execute(select(UserRole).where(UserRole.user_id == user.id).join(UserRole.role))
        .scalars()
        .all()
    )
    role_names = [ur.role.name for ur in roles] or [RoleName.viewer]
    precedence = {RoleName.admin: 3, RoleName.security_analyst: 2, RoleName.viewer: 1}
    role = sorted(role_names, key=lambda r: precedence[r], reverse=True)[0]

    token = create_access_token(subject=str(user.id), role=role.value)
    return TokenResponse(access_token=token, role=role)
