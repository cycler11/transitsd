from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import require_roles
from app.db.session import get_db
from app.models import AuditLog, RoleName

router = APIRouter()


@router.get("", dependencies=[Depends(require_roles(RoleName.admin, RoleName.security_analyst, RoleName.viewer))])
def list_audit_logs(db: Session = Depends(get_db), limit: int = 200, offset: int = 0):
    rows = (
        db.execute(select(AuditLog).order_by(AuditLog.at.desc()).limit(limit).offset(offset))
        .scalars()
        .all()
    )
    return {
        "items": [
            {
                "id": str(a.id),
                "at": a.at,
                "actor_user_id": str(a.actor_user_id) if a.actor_user_id else None,
                "action": a.action,
                "entity": a.entity,
                "entity_id": a.entity_id,
                "details": a.details,
            }
            for a in rows
        ],
        "limit": limit,
        "offset": offset,
    }
