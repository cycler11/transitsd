from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import require_roles
from app.db.session import get_db
from app.models import RoleName, Vulnerability

router = APIRouter()


@router.get("", dependencies=[Depends(require_roles(RoleName.admin, RoleName.security_analyst, RoleName.viewer))])
def list_vulnerabilities(db: Session = Depends(get_db), limit: int = 100, offset: int = 0):
    rows = (
        db.execute(select(Vulnerability).order_by(Vulnerability.created_at.desc()).limit(limit).offset(offset))
        .scalars()
        .all()
    )
    return {
        "items": [
            {
                "id": str(v.id),
                "title": v.title,
                "severity": v.severity,
                "cvss_score": v.cvss_score,
                "cves": v.cves,
                "created_at": v.created_at,
            }
            for v in rows
        ],
        "limit": limit,
        "offset": offset,
    }
