from fastapi import APIRouter

from app.api.routers import (
    assets,
    audit_logs,
    auth,
    connections,
    reports,
    scan_jobs,
    scan_runs,
    vulnerabilities,
)

api_router = APIRouter()

api_router.include_router(auth.router, tags=["auth"])
api_router.include_router(connections.router, prefix="/connections", tags=["connections"])
api_router.include_router(assets.router, prefix="/assets", tags=["assets"])
api_router.include_router(scan_jobs.router, prefix="/scan-jobs", tags=["scan-jobs"])
api_router.include_router(scan_runs.router, prefix="/scan-runs", tags=["scan-runs"])
api_router.include_router(vulnerabilities.router, prefix="/vulnerabilities", tags=["vulnerabilities"])
api_router.include_router(reports.router, prefix="/reports", tags=["reports"])
api_router.include_router(audit_logs.router, prefix="/audit-logs", tags=["audit-logs"])
