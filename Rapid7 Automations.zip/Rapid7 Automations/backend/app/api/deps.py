from __future__ import annotations

import uuid
from dataclasses import dataclass

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.session import get_db
from app.models import RoleName, User, UserRole

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")


@dataclass(frozen=True)
class AuthContext:
    user: User
    role: RoleName


def get_current_auth(
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme),
) -> AuthContext:
    try:
        payload = jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
        sub = payload.get("sub")
        role = payload.get("role")
        if not sub or not role:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")
        user_id = uuid.UUID(sub)
        role_name = RoleName(role)
    except (JWTError, ValueError):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")

    user = db.get(User, user_id)
    if not user or not user.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Inactive user")

    # Ensure role still assigned
    role_ok = db.execute(
        select(UserRole).where(UserRole.user_id == user.id).join(UserRole.role).where(UserRole.role.has(name=role_name))
    ).scalar_one_or_none()
    if not role_ok:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Role not assigned")

    return AuthContext(user=user, role=role_name)


def require_roles(*allowed: RoleName):
    def _inner(ctx: AuthContext = Depends(get_current_auth)) -> AuthContext:
        if ctx.role not in allowed:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Insufficient role")
        return ctx

    return _inner
