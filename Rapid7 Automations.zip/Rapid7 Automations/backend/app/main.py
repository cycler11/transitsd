from __future__ import annotations

from fastapi import FastAPI

from app.api.router import api_router

app = FastAPI(title="Rapid7 Automation API", version="0.1.0")


@app.get("/healthz")
def healthz():
    return {"ok": True}


app.include_router(api_router)

