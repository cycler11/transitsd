#!/usr/bin/env sh
set -eu

echo "Running migrations..."
alembic upgrade head

echo "Seeding admin (idempotent)..."
python -m app.seed || true

echo "Starting API..."
exec uvicorn app.main:app --host 0.0.0.0 --port 8000

