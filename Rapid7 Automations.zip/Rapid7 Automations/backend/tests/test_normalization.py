from app.models import Severity
from app.utils.normalization import normalize_asset, normalize_vulnerability


def test_normalize_asset_fields():
    a = normalize_asset({"id": "a1", "hostname": "h", "ip": "1.2.3.4", "extra": 1})
    assert a.rapid7_asset_id == "a1"
    assert a.hostname == "h"
    assert a.ip == "1.2.3.4"
    assert a.metadata["extra"] == 1


def test_normalize_vulnerability_severity_mapping():
    v = normalize_vulnerability({"id": "v1", "title": "t", "severity": "CRITICAL", "cvss": 9})
    assert v.rapid7_vuln_id == "v1"
    assert v.severity == Severity.critical
    assert v.cvss_score == 9
