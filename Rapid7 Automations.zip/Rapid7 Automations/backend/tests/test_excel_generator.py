from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from app.models import Severity
from app.reports.generator import generate_xlsx_report_from_db


@dataclass
class _FakeAsset:
    id: str
    hostname: str | None
    ip: str | None
    rapid7_asset_id: str | None
    created_at: datetime


@dataclass
class _FakeVuln:
    id: str
    title: str
    severity: Severity
    cvss_score: int | None
    rapid7_vuln_id: str | None
    created_at: datetime


class _ScalarResult:
    def __init__(self, items):
        self._items = items

    def all(self):
        return self._items


class _ExecResult:
    def __init__(self, items):
        self._items = items

    def scalars(self):
        return _ScalarResult(self._items)


class _FakeDb:
    def __init__(self, assets, vulns):
        self.assets = assets
        self.vulns = vulns

    def execute(self, stmt):
        s = str(stmt)
        if "FROM assets" in s:
            return _ExecResult(self.assets)
        if "FROM vulnerabilities" in s:
            return _ExecResult(self.vulns)
        return _ExecResult([])

    def get(self, model, report_id):
        _ = model, report_id
        return None

    def commit(self):
        return None


def test_excel_generator_creates_file(tmp_path: Path, monkeypatch):
    # Redirect report output root
    monkeypatch.setenv("DATABASE_URL", "sqlite://")  # irrelevant for this test
    monkeypatch.setenv("REPORT_DIR", tmp_path.as_posix())

    assets = [_FakeAsset("a1", "h1", "10.0.0.1", "r1", datetime.now(UTC))]
    vulns = [_FakeVuln("v1", "t1", Severity.high, 8, "rv1", datetime.now(UTC))]
    db = _FakeDb(assets, vulns)

    fp = generate_xlsx_report_from_db(db=db, report_id="rpt1")
    assert Path(fp).exists()
