from app.rapid7.client import MockRapid7Client


def test_mock_client_loads_fixtures():
    c = MockRapid7Client()
    assets = c.fetch_assets()
    vulns = c.fetch_vulnerabilities()
    assert isinstance(assets, list) and len(assets) >= 1
    assert isinstance(vulns, list) and len(vulns) >= 1
