from app.models import Severity
from app.utils.priority import remediation_priority_score


def test_priority_score_monotonic_by_severity():
    critical = remediation_priority_score(severity=Severity.critical, cvss_score=10)
    high = remediation_priority_score(severity=Severity.high, cvss_score=10)
    medium = remediation_priority_score(severity=Severity.medium, cvss_score=10)
    low = remediation_priority_score(severity=Severity.low, cvss_score=10)
    info = remediation_priority_score(severity=Severity.info, cvss_score=10)
    assert critical > high > medium > low > info


def test_priority_score_cvss_bounds():
    s1 = remediation_priority_score(severity=Severity.high, cvss_score=-10)
    s2 = remediation_priority_score(severity=Severity.high, cvss_score=0)
    s3 = remediation_priority_score(severity=Severity.high, cvss_score=999)
    assert s1 == s2
    assert s3 == remediation_priority_score(severity=Severity.high, cvss_score=10)
