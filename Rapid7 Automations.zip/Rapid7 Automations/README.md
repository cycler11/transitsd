# Rapid7 Nexpose / InsightVM Automation (Scaffold)

Enterprise-ready monorepo scaffold for automating Rapid7 Nexpose/InsightVM workflows.

## What’s included

- **Monorepo**: `backend/` (FastAPI), `frontend/` (Next.js + MUI), `docker-compose.yml`
- **Services**: backend, worker, scheduler, frontend, postgres, redis (+ healthchecks)
- **Backend**:
  - SQLAlchemy 2.0 models + Alembic migrations for:
    `rapid7_connections`, `assets`, `scan_jobs`, `scan_runs`, `vulnerabilities`,
    `asset_vulnerabilities`, `software`, `open_ports`, `reports`, `audit_logs`,
    plus `users/roles`
  - Field-level encryption for connection secrets using `ENCRYPTION_KEY` (Fernet)
  - Rapid7 client layer with a **mock mode** (`MOCK_MODE=1`) using JSON fixtures in `backend/mock_data/`
  - Celery worker + beat scheduler containers
  - XLSX report generator (xlsxwriter) with sheets, header freeze, autofilter, severity coloring
  - OpenAPI docs enabled (FastAPI `/docs`)
- **Frontend**:
  - Pages: Dashboard, Connections, Assets, Scan Jobs, Scan Runs, Vulnerabilities, Remediation Plan, Reports, Settings, Audit Log
  - JWT login flow (stores token locally; role shown in header)

## Quick start (mock mode)

1. Copy env example (optional):

```bash
cp .env.example .env
```

2. Set required secrets in `.env`:
   - `ENCRYPTION_KEY`
   - `JWT_SECRET`

3. Start stack:

```bash
docker compose --env-file .env up --build
```

The backend container runs `alembic upgrade head` and seeds an initial admin user.

- **Backend**: `http://localhost:8000` (docs at `/docs`)
- **Frontend**: `http://localhost:3000`

Default seeded credentials (override in env):
- `SEED_ADMIN_EMAIL=admin@example.com`
- `SEED_ADMIN_PASSWORD=ChangeMe123!`

## Rapid7 real mode (placeholders)

Set:
- `MOCK_MODE=0`
- `RAPID7_BASE_URL` (do not hardcode; must match your deployment)
- `RAPID7_API_VERSION`
- Create a connection via the API (`POST /connections`) with an API token.

**Important**: The `Rapid7Client` methods are intentionally placeholders because Nexpose/InsightVM endpoints vary by installed version. Wire the correct paths and pagination/rate-limit behavior for your environment.

## Backend dev commands (inside `backend/`)

```bash
pip install -r requirements.txt
alembic upgrade head
python -m app.seed
pytest -q
uvicorn app.main:app --reload
```

## Notes on secrets / logging

- Connection tokens are stored encrypted at rest (`api_token_enc`) using `ENCRYPTION_KEY`.
- API responses **mask** secrets and the scaffold avoids logging secret material.

