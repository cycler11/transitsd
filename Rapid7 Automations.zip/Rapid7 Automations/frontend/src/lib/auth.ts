export type Role = "Admin" | "SecurityAnalyst" | "Viewer";

const TOKEN_KEY = "r7_token";
const ROLE_KEY = "r7_role";

export function setAuth(token: string, role: Role) {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(ROLE_KEY, role);
}

export function clearAuth() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(ROLE_KEY);
}

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function getRole(): Role | null {
  return (localStorage.getItem(ROLE_KEY) as Role | null) ?? null;
}

export function hasRole(allowed: Role[]): boolean {
  const role = getRole();
  return role ? allowed.includes(role) : false;
}

