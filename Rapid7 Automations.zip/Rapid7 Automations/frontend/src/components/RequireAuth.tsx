import { useEffect } from "react";
import { useRouter } from "next/router";
import { getToken, hasRole, Role } from "../lib/auth";

export function useRequireAuth(allowedRoles?: Role[]) {
  const router = useRouter();
  useEffect(() => {
    const token = getToken();
    if (!token) {
      router.replace("/login");
      return;
    }
    if (allowedRoles && !hasRole(allowedRoles)) {
      router.replace("/dashboard");
    }
  }, [allowedRoles, router]);
}

