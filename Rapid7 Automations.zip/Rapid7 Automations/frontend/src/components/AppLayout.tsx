import React from "react";
import Link from "next/link";
import { useRouter } from "next/router";
import {
  AppBar,
  Box,
  Button,
  Container,
  Toolbar,
  Typography
} from "@mui/material";
import { clearAuth, getRole } from "../lib/auth";

const nav = [
  { href: "/dashboard", label: "Dashboard" },
  { href: "/connections", label: "Connections" },
  { href: "/assets", label: "Assets" },
  { href: "/scan-jobs", label: "Scan Jobs" },
  { href: "/scan-runs", label: "Scan Runs" },
  { href: "/vulnerabilities", label: "Vulnerabilities" },
  { href: "/remediation", label: "Remediation Plan" },
  { href: "/reports", label: "Reports" },
  { href: "/settings", label: "Settings" },
  { href: "/audit-log", label: "Audit Log" }
];

export function AppLayout({
  title,
  children
}: {
  title: string;
  children: React.ReactNode;
}) {
  const router = useRouter();
  const role = typeof window !== "undefined" ? getRole() : null;

  return (
    <Box>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            {title}
          </Typography>
          <Typography variant="body2" sx={{ mr: 2 }}>
            {role ? `Role: ${role}` : ""}
          </Typography>
          <Button
            color="inherit"
            onClick={() => {
              clearAuth();
              router.push("/login");
            }}
          >
            Logout
          </Button>
        </Toolbar>
      </AppBar>
      <Box sx={{ bgcolor: "#fafafa", borderBottom: "1px solid #eee" }}>
        <Container sx={{ py: 1, display: "flex", gap: 2, flexWrap: "wrap" }}>
          {nav.map((n) => (
            <Link key={n.href} href={n.href}>
              {n.label}
            </Link>
          ))}
        </Container>
      </Box>
      <Container sx={{ py: 3 }}>{children}</Container>
    </Box>
  );
}

