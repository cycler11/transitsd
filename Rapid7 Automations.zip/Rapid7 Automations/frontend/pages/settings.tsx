import { Card, CardContent, Typography } from "@mui/material";
import { AppLayout } from "../src/components/AppLayout";
import { useRequireAuth } from "../src/components/RequireAuth";

export default function SettingsPage() {
  useRequireAuth();
  return (
    <AppLayout title="Settings">
      <Card>
        <CardContent>
          <Typography variant="h6">Settings (Scaffold)</Typography>
          <Typography variant="body2" sx={{ mt: 1, color: "text.secondary" }}>
            Add user management, feature flags, and Rapid7 endpoint configuration here.
          </Typography>
        </CardContent>
      </Card>
    </AppLayout>
  );
}

