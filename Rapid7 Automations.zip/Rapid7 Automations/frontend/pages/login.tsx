import { useState } from "react";
import { useRouter } from "next/router";
import { Alert, Box, Button, Container, TextField, Typography } from "@mui/material";
import { api } from "../src/lib/api";
import { setAuth } from "../src/lib/auth";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("admin@example.com");
  const [password, setPassword] = useState("ChangeMe123!");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  return (
    <Container maxWidth="sm" sx={{ py: 8 }}>
      <Typography variant="h4" sx={{ mb: 2 }}>
        Login
      </Typography>
      <Typography variant="body2" sx={{ mb: 3, color: "text.secondary" }}>
        Default credentials are configurable via backend seed env vars.
      </Typography>
      {error ? <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert> : null}
      <Box
        component="form"
        onSubmit={async (e) => {
          e.preventDefault();
          setLoading(true);
          setError(null);
          try {
            const res = await api.post("/auth/login", { email, password });
            setAuth(res.data.access_token, res.data.role);
            router.push("/dashboard");
          } catch (err: any) {
            setError(err?.response?.data?.detail ?? "Login failed");
          } finally {
            setLoading(false);
          }
        }}
        sx={{ display: "flex", flexDirection: "column", gap: 2 }}
      >
        <TextField label="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
        <TextField label="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        <Button type="submit" variant="contained" disabled={loading}>
          {loading ? "Signing in..." : "Sign in"}
        </Button>
      </Box>
    </Container>
  );
}

