import { useEffect, useState } from "react";
import { Alert, Button, Card, CardContent, Typography } from "@mui/material";
import { AppLayout } from "../src/components/AppLayout";
import { useRequireAuth } from "../src/components/RequireAuth";
import { api } from "../src/lib/api";

export default function AssetsPage() {
  useRequireAuth();
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    setError(null);
    try {
      const res = await api.get("/assets?limit=50&offset=0");
      setData(res.data);
    } catch (e: any) {
      setError(e?.response?.data?.detail ?? "Failed to load");
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  return (
    <AppLayout title="Assets">
      {error ? <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert> : null}
      <Card>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2 }}>Assets</Typography>
          <Button variant="outlined" onClick={refresh}>Refresh</Button>
          <pre style={{ marginTop: 16, overflow: "auto" }}>
            {JSON.stringify(data, null, 2)}
          </pre>
        </CardContent>
      </Card>
    </AppLayout>
  );
}

