import { useState } from "react";
import { Alert, Box, Button, Card, CardContent, Typography } from "@mui/material";
import { AppLayout } from "../src/components/AppLayout";
import { useRequireAuth } from "../src/components/RequireAuth";
import { api, apiBaseUrl } from "../src/lib/api";

export default function ReportsPage() {
  useRequireAuth();
  const [error, setError] = useState<string | null>(null);
  const [reportId, setReportId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  return (
    <AppLayout title="Reports">
      {error ? <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert> : null}
      <Card>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2 }}>Reports</Typography>
          <Box sx={{ display: "flex", gap: 2, flexWrap: "wrap" }}>
            <Button
              variant="contained"
              disabled={loading}
              onClick={async () => {
                setLoading(true);
                setError(null);
                try {
                  const res = await api.post("/reports/generate", { name: "InsightVM Report", kind: "xlsx" });
                  setReportId(res.data.report_id);
                } catch (e: any) {
                  setError(e?.response?.data?.detail ?? "Failed to generate");
                } finally {
                  setLoading(false);
                }
              }}
            >
              {loading ? "Generating..." : "Generate XLSX"}
            </Button>
            {reportId ? (
              <Button
                variant="outlined"
                href={`${apiBaseUrl}/reports/${reportId}/download`}
                target="_blank"
              >
                Download
              </Button>
            ) : null}
          </Box>
          <Typography variant="body2" sx={{ mt: 2, color: "text.secondary" }}>
            Reports are generated from DB data (mock fixtures in mock mode).
          </Typography>
        </CardContent>
      </Card>
    </AppLayout>
  );
}

