import { Card, CardContent, Typography } from "@mui/material";
import { AppLayout } from "../src/components/AppLayout";
import { useRequireAuth } from "../src/components/RequireAuth";

export default function Dashboard() {
  useRequireAuth();
  return (
    <AppLayout title="Dashboard">
      <Card>
        <CardContent>
          <Typography variant="h6">Rapid7 Automation (Mock-ready)</Typography>
          <Typography variant="body2" sx={{ color: "text.secondary", mt: 1 }}>
            Use the navigation to manage connections, launch scan jobs, and generate reports.
          </Typography>
        </CardContent>
      </Card>
    </AppLayout>
  );
}

