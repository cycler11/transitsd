import { Card, CardContent, Typography } from "@mui/material";
import { AppLayout } from "../src/components/AppLayout";
import { useRequireAuth } from "../src/components/RequireAuth";

export default function RemediationPlanPage() {
  useRequireAuth();
  return (
    <AppLayout title="Remediation Plan">
      <Card>
        <CardContent>
          <Typography variant="h6">Remediation Plan (Scaffold)</Typography>
          <Typography variant="body2" sx={{ mt: 1, color: "text.secondary" }}>
            This page will derive remediation groups from persisted vulnerabilities + assets.
          </Typography>
        </CardContent>
      </Card>
    </AppLayout>
  );
}

