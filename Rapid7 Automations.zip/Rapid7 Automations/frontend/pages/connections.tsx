import { useEffect, useState } from "react";
import { Alert, Button, Card, CardContent, Typography } from "@mui/material";
import { AppLayout } from "../src/components/AppLayout";
import { useRequireAuth } from "../src/components/RequireAuth";
import { api } from "../src/lib/api";
import { Role } from "../src/lib/auth";

type ConnectionRow = {
  id: string;
  name: string;
  base_url: string;
  api_version: string;
  verify_tls: boolean;
  is_active: boolean;
};

export default function ConnectionsPage() {
  useRequireAuth();
  const [items, setItems] = useState<ConnectionRow[]>([]);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    setError(null);
    try {
      const res = await api.get("/connections");
      setItems(res.data);
    } catch (e: any) {
      setError(e?.response?.data?.detail ?? "Failed to load");
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  return (
    <AppLayout title="Connections">
      {error ? <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert> : null}
      <Card>
        <CardContent>
          <Typography variant="h6" sx={{ mb: 2 }}>
            Rapid7 Connections
          </Typography>
          <Button variant="outlined" onClick={refresh}>
            Refresh
          </Button>
          <Typography variant="body2" sx={{ mt: 2, color: "text.secondary" }}>
            {items.length} connection(s)
          </Typography>
          <pre style={{ marginTop: 16, overflow: "auto" }}>
            {JSON.stringify(items, null, 2)}
          </pre>
        </CardContent>
      </Card>
    </AppLayout>
  );
}

